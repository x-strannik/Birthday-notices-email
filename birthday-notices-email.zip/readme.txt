=== Birthday notices email ===
Plugin Name: Birthday notices email
Plugin URI: : https://kodabra.unchikov.ru/birthday-notices-email/
Description: Уведомления о днях рождения на email, если у вас есть записи персон, имеющих поле "дата рождения".
Author: Elena Unchikova
Version: 1.0.0
Author URI: https://kodabra.unchikov.ru/

Плагин для WordPress "Birthday notices email".

== Description ==

Уведомления о днях рождения на email, если у вас есть записи персон, имеющих поле "дата рождения".

Код изначально писался под плагин генеалогического древа для WordPress "TreePress — Easy Family Trees & Ancestor Profiles".

Если у вас есть записи персон, имеющих поле "дата рождения", замените "member" на свой тип записи.
Если у вас дата рождения не в формате "гггг-мм-дд" измените переменные "$tmes" и "$pstdr" в соответствии со своим форматом, чтобы остались день и месяц.
Не забудьте вместо "ваша_эл_почта" вписать ваш E-mail.

== Installation ==

Вместо «ваша_эл_почта» впишите ваш E-mail, загрузите плагин Birthday notices email в свой блог и активируйте его.